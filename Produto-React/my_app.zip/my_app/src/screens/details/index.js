import React from 'react';
import { View, Text, Button } from 'react-native';

export default function DetailsScreen({route, navigation }) {
  let {productId, name} = route.params
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Detalhes</Text>
      <Text>ID: {productId} </Text>
      <Text>Nome: {name}</Text>
      <Button title="Voltar" onPress={() => navigation.goBack()} />
    </View>
  );
}