import { Text } from 'react-native';
import { styles } from './styles';

export function Cabecalho() {
  return (
    
      <Text style={styles.texth1}>RODOLFO F. SILVA</Text>
     
  );
}


