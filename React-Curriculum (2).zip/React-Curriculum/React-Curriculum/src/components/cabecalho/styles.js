import { StyleSheet } from 'react-native';


export let styles = StyleSheet.create({
  texth1:{
    color: '#fff',
     width: '50%',
     fontSize: '25px',
     textAlign: 'center'
  }
});