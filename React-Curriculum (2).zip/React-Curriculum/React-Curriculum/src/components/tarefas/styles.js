import { StyleSheet } from 'react-native';


export let styles = StyleSheet.create({
  tinyLogo: {
    width: 50,
    height: 50,
    borderRadius: '25%',
    shadowColor:  '60px -16px teal;'
  },
  tarefas:{
    display: 'flex',
    backgroundColor: '#000',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '95%',
    gap: '20px', 
    marginTop: '10px',
    border: 'solid gray 2px',
    padding: '10px',
    paddingLeft: '30px',
    paddingRight: '30px',
    borderRadius: '10px'
  }, 
  text:{
    color: '#fff',
     width: '50%',
     fontSize: '10px',
     textAlign: 'justify'
  },
});