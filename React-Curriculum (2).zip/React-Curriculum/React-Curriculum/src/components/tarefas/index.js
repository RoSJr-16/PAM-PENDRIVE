
import { Text, View, Image } from 'react-native';
import { styles } from './styles';
import { Fragment } from 'react/jsx-runtime';

export function Tarefas() {
  return (
  <Fragment>
     <View style={styles.tarefas}>
          <Image
          style={styles.tinyLogo}
          source={require('/src/img/images.jpg')}
          />

                     <Text style={styles.text}>
                         <Text style={{fontWeight: "bold"}}>Profissão: </Text>Programador
                          <br/>
                          <Text style={{fontWeight: "bold"}}>Idade: </Text> 39 anos
                          <br/>
                          <Text style={{fontWeight: "bold"}}>Telefone: </Text> (11) 4002-8922
                          <br/>
                          <Text style={{fontWeight: "bold"}}>Endereço: </Text> Rua da Lima, 189
                    </Text>
                </View>
          
                <br/>
          
                <View  style={styles.tarefas}>
                    
                     <Text style={styles.text}>
                      <Text style={{fontWeight: "bold"}}>EXPERIÊNCIAS</Text>
                      <br/>
                      <br/>
                        1978 | Serviu o exército
                        <br/>
                        1980 | Programador Junior na Nintendo
                        <br/>
                        1987 | Chefe de Cozinha
                        <br/>
                        1993 | Programador Junior na Capcom
                        <br/>
                        2001 | Programador Senior na Konami
                    </Text>
                </View>
          
                <br/>
                
                <View style={styles.tarefas}>
                     <Text style={styles.text}>
                      <Text style={{fontWeight: "bold"}}>FORMAÇÕES</Text>
                      <br/>
                      <br/>
                          Programação na USP -  1985
                          <br/>
                          Doutorado Programação na USP - 1997
                      </Text>
                </View>
          
                <View style={styles.tarefas}>
                     <Text style={styles.text}>
                      <Text style={{fontWeight: "bold"}}>LINGUAS</Text>
                      <br/>
                      <br/>
                          Inglês, Espanhol e Russo
                      </Text>
                </View>
                <br/>
  </Fragment>
  );
}



      