import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, ImageBackground } from 'react-native';
import { Cabecalho } from './src/components/cabecalho/cabecalho.js'
import { Tarefas } from './src/components/tarefas/index.js';


export default function App() {
  return (
  <View style={styles.container}>
      <View style={styles.tarefas}>


      <Cabecalho></Cabecalho>
      <Tarefas></Tarefas>


      
      </View>
  </View>
  );
}

const styles = StyleSheet.create({

  container: {
    display: 'flex',
    backgroundColor: '#00183bff',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '120%',
   
  },  
  fundo:{
    height: '100%',
    width: '100%', 
    display: 'flex',
    justifyContent: 'center',
    position: 'absolute'
  },
});
