{/* npx expo install expo-location */}

import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ActivityIndicator } from 'react-native';
import * as Location from 'expo-location';

export default function App() {
  
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  useEffect(() => {
    let subscription = null;

    const startLocationTracking = async () => {
      
      const { status } = await Location.requestForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        setErrorMsg('A permissão para acessar a localização foi negada.');
        return;
      }

      
      subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 3000,
          distanceInterval: 5,
        },
        (newLocation) => {
          setLocation(newLocation);
        }
      );
    };

    startLocationTracking();

    return () => {
      if (subscription) {
        subscription.remove();
      }
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📍 Geolocalização Automática</Text>

      {errorMsg ? (
        <Text style={styles.error}>{errorMsg}</Text>
      ) : location ? (
        <View style={styles.card}>
          <Text style={styles.label}>Latitude:</Text>
          <Text style={styles.value}>{location.coords.latitude}</Text>

          <Text style={styles.label}>Longitude:</Text>
          <Text style={styles.value}>{location.coords.longitude}</Text>

          <Text style={styles.label}>Velocidade:</Text>
          <Text style={styles.value}>
            {location.coords.speed && location.coords.speed > 0
              ? `${(location.coords.speed * 3.6).toFixed(1)} km/h`
              : '0 km/h'}
          </Text>
        </View>
      ) : (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color="#0066CC" />
          <Text style={styles.loadingText}>Buscando sinal do GPS...</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  card: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 12,
    width: '100%',
    elevation: 3,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  value: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0066CC',
  },
  error: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
  },
  loading: {
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
  },
});